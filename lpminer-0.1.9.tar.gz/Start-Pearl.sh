#!/bin/sh

./lpminer --algo pearl --pool stratum+tcp://prl.kryptex.network:7048 --wallet prl1pawh48t67ullph5z84ayewler6s3tha6zcxm8dghlz3gudldh523s9lm5pc.MyFirstRig